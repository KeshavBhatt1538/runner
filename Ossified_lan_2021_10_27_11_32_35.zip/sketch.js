var PLAY = 1;
var END = 0;
var gameState = PLAY;


var bg ,bgimg,backgroundImage
var player,playerimg
var ground,groundImage

function preload(){
  
 backgroundImage= loadImage("bg.jpeg");
 playerimg=loadImage("player.png") 
 
}



function setup() {
  createCanvas(600, 400);
  
  //creating background
  background = createSprite(100,100,400,200);
  background.addImage(backgroundImage);
  background.scale = 1.7
  player = createSprite(50,300,20,50);
  
  player.addImage("running", playerimg);
  //.addAnimation("collided", trex_collided);
  player.scale = 0.3;
  
 // ground = createSprite(200,300,1000,20);
 // ground.addImage("ground",groundImage);
  //ground.x = ground.width /2;

 // ground.velocityX = -(6 + 3*score/100);
  invisibleGround = createSprite(200,340,400,10);
  invisibleGround.visible = false;
}

function draw() {

  // moving ground
    background.velocityX = -3 

    if (background.x < 0){
      background.x = background.width/2;
    }
  
 //  ground.velocityX=-4
 // if(ground.x<0){
  //ground.x=ground.width/2   
     
    // }
  
 if (keyDown("space") && player.y >=100) {
    player.velocityY=-8
 
 }
  player.velocityY+=0.8

  
  player.collide(invisibleGround)
  
  drawSprites();
  //  text("Score: "+ score, 500,50);
}
function control(){
  
  
  
  
  
  
  
}


